import Link from "next/link";

export default function MenuAdmin() {
    return (
        <div className="d-flex justify-content-center bg-info" style={{ gap: '0' }}>
    <div 
        className="p-2" 
        style={{
            transition: 'background-color 0.3s ease', 
            cursor: 'pointer',
            padding: '10px 20px', 
            borderRadius: '0', 
            width: '100%',
            textAlign: 'center',
        }}
        onMouseOver={(e) => e.currentTarget.style.backgroundColor = 'skyblue'}
        onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
        title="Voltar à página inicial" 
    >
        <Link className="navbar-brand nav-item" style={{color: 'white'}} href="/admin"><strong>PÁGINA INICIAL</strong></Link>
    </div>

    <div 
        className="p-2" 
        style={{
            transition: 'background-color 0.3s ease', 
            cursor: 'pointer',
            padding: '10px 20px', 
            borderRadius: '0', 
            width: '100%',
            textAlign: 'center', 
        }}
        onMouseOver={(e) => e.currentTarget.style.backgroundColor = 'skyblue'}
        onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
        title="Listagem rápida"
    >
        <Link className="navbar-brand nav-item" style={{color: 'white'}} href="/admin/users"><strong>USUÁRIOS</strong></Link>
    </div>

    <div 
        className="p-2" 
        style={{
            transition: 'background-color 0.3s ease', 
            cursor: 'pointer',
            padding: '10px 20px', 
            borderRadius: '0', 
            width: '100%',
            textAlign: 'center',
        }}
        onMouseOver={(e) => e.currentTarget.style.backgroundColor = 'skyblue'}
        onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
        title="Listagem rápida"
    >
        <Link className="navbar-brand nav-item" style={{color: 'white'}} href="/admin/students"><strong>ESTUDANTES</strong></Link>
    </div>

    <div 
        className="p-2" 
        style={{
            transition: 'background-color 0.3s ease', 
            cursor: 'pointer',
            padding: '10px 20px', 
            borderRadius: '0', 
            width: '100%',
            textAlign: 'center',
        }}
        onMouseOver={(e) => e.currentTarget.style.backgroundColor = 'skyblue'}
        onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
        title="Listagem rápida" 
    >
        <Link className="navbar-brand nav-item" style={{color: 'white'}} href="/admin/teachers"><strong>PROFESSORES</strong></Link>
    </div>

    <div 
        className="p-2" 
        style={{
            transition: 'background-color 0.3s ease', 
            cursor: 'pointer',
            padding: '10px 20px', 
            borderRadius: '0', 
            width: '100%',
            textAlign: 'center', 
        }}
        onMouseOver={(e) => e.currentTarget.style.backgroundColor = 'skyblue'}
        onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
        title="Listagem rápida" 
    >
        <Link className="navbar-brand nav-item" style={{color: 'white'}} href="/admin/appointments"><strong>AGENDAMENTOS</strong></Link>
    </div>

            <div 
        className="p-2" 
        style={{
            transition: 'background-color 0.3s ease', 
            cursor: 'pointer',
            padding: '10px 20px', 
            borderRadius: '0', 
            width: '100%',
            textAlign: 'center', 
        }}
        onMouseOver={(e) => e.currentTarget.style.backgroundColor = 'skyblue'}
        onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
        title="Listagem rápida" 
    >
        <Link className="navbar-brand nav-item" style={{color: 'white'}} href="/admin/professionals"><strong>PROFISSIONAIS</strong></Link>
    </div>
    <div 
        className="p-2" 
        style={{
            transition: 'background-color 0.3s ease', 
            cursor: 'pointer',
            padding: '10px 20px', 
            borderRadius: '0', 
            width: '100%',
            textAlign: 'center', 
        }}
        onMouseOver={(e) => e.currentTarget.style.backgroundColor = 'skyblue'}
        onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
        title="Listagem rápida" 
    >
        <Link className="navbar-brand nav-item" style={{color: 'white'}} href="/admin/events"><strong>EVENTOS</strong></Link>
    </div>
</div>
)
}
