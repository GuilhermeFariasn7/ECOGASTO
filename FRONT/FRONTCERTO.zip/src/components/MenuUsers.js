import Link from "next/link";
import MenuAdmin from '@/components/MenuAdmin';

export default function MenuUsers() {
    return (

    <div>
        <MenuAdmin />
    </div>

    )
}