import Link from "next/link";
import { useRouter } from 'next/router';
export default function MenuAdmin() {
    const router = useRouter();
    return (

        <div className="d-flex justify-content-center bg-secondary" style={{ gap: '0' }}>
            <div
                className="p-2"
                style={{
                    transition: 'background-color 0.3s ease',
                    cursor: 'pointer',
                    padding: '10px 20px',
                    borderRadius: '0',
                    width: '100%',
                    textAlign: 'center',
                }}
                onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#67cf8d'}
                onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                onClick={router.push('/home/')}
                title="Página inicial"
            >
                <strong>HOME</strong>
            </div>

            <div
                className="p-2 navbar-brand nav-item"
                style={{
                    transition: 'background-color 0.3s ease',
                    cursor: 'pointer',
                    padding: '10px 20px',
                    borderRadius: '0',
                    width: '100%',
                    textAlign: 'center',
                }}
                onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#67cf8d'}
                onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                onClick={router.push('/extrato/')}
                title="Visualizar Extrato de pagamentos"
            >   <strong>EXTRATO</strong>
            </div>

            <div
                className="p-2"
                style={{
                    transition: 'background-color 0.3s ease',
                    cursor: 'pointer',
                    padding: '10px 20px',
                    borderRadius: '0',
                    width: '100%',
                    textAlign: 'center',
                }}
                onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#67cf8d'}
                onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                title="Listagem rápida"
            >
                <Link className="navbar-brand nav-item" style={{ color: 'white' }} href="/home/"><strong>METAS</strong></Link>
            </div>


        </div >
    )
}
