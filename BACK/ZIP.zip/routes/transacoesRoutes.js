const router = require('express').Router();
const transacoesController = require('../controllers/transacoesController');

router
.route('/transacoes')
.post((req, res) => transacoesController.create(req, res));

router
.route('/transacoes')
.get((req, res) => transacoesController.getAll(req, res));

router
.route('/transacoes/:id')
.get((req, res) => transacoesController.getId(req, res));

router
.route('/transacoes/name/:name')
.get((req, res) => transacoesController.getName(req, res));

router
.route('/transacoes/:id')
.delete((req, res) => transacoesController.delete(req, res));

router
.route('/transacoes/:id')
.put((req, res) =>  transacoesController.update(req, res));


module.exports = router;