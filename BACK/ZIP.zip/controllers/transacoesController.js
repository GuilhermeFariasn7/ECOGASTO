const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const connect = require('../db/conn'); // Importar a função de conexão

// Inicialize a conexão globalmente
let connection;

(async () => {
    try {
        connection = await connect(); // Configure a conexão uma vez
    } catch (error) {
        console.error("Erro ao conectar ao banco de dados:", error);
    }
})();

const transacoesController = {

    create: async (req, res) => {
        try {
            /* nome: nome,
                descricao: descricao,
                valor: parseFloat(valorGastos),
                categoria_idcategoria: idCategoria,
                conta_idconta: idConta,
                data_inicio: dataInicio,
                data_fim: lastDataFim,
                status: 'pendente',
                numParcelas: numParcelas,
                dia_util: (checkdiautil),
                diaParcela: parseInt(diaParcela),  */ // Valor padrão
            const { nome,descricao,valor,categoria_idcategoria,conta_idconta,data_inicio,data_fim,status,numParcelas,dia_util,diaParcela} = req.body;  
            console.log(req.body);
            // Verificar se o login já existe
            const [results] = await connection.execute('SELECT nome FROM transacoes WHERE nome = ?', [nome]);

            if (results.length > 0) {
                return res.status(409).json({ msg: "Já existe uma transação registrada com este nome!" });
            }

            const query = `INSERT INTO transacoes (nome, descricao, valor, categoria_idcategoria, data_ini, data_fim, status, num_parcelas, dia_util, num_dia) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;            
            await connection.execute(query, [nome,descricao,valor,categoria_idcategoria,data_inicio,data_fim,status,numParcelas,dia_util,diaParcela]);

            res.status(200).json({ msg: "Categoria criada com sucesso!" });
        } catch (error) {
            console.error(error);
            res.status(500).json({ msg: "Erro ao criar transação, por gentileza verifique os dados digitados" });
        }
    },

    getAll: async (req, res) => {
        try {
            const [results] = await connection.execute('SELECT * FROM categoria');
            res.status(200).json(results);
        } catch (error) {
            console.error(error);
            res.status(500).json({ msg: "Erro ao buscar os categoria" });
        }
    },

    getId: async (req, res) => {
        try {
            const id = req.params.id;
            const [results] = await connection.execute('SELECT * FROM categoria WHERE idcategoria = ?', [id]);
            if (results.length === 0) {
                return res.status(404).json({ msg: "categoria não encontrado" });
            }
            res.status(200).json(results[0]);
        } catch (error) {
            console.error(error);
            res.status(500).json({ msg: "Erro ao buscar o categoria" });
        }
    },

    getName: async (req, res) => {
        try {
            const nome = req.params.nome;
            const [results] = await connection.execute('SELECT * FROM categoria WHERE nome = ?', [nome]);
            if (results.length === 0) {
                return res.status(404).json({ msg: "categoria não encontrado" });
            }
            res.status(200).json(results[0]);
        } catch (error) {
            console.error(error);
            res.status(500).json({ msg: "Erro ao buscar o categoria" });
        }
    },

    delete: async (req, res) => {
        
    },

    update: async (req, res) => {
        
    }
};

module.exports = transacoesController;
